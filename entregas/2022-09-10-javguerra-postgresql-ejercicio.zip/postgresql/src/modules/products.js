const products = [
    {
        'name': 'AUDI TT RS',
        'manufacter': 'N0042609H',
        'price': 92910,
        'color': 'red'
    },
    {
        'name': 'VOLKSWAGEN GOLF R',
        'manufacter': 'A60198512',
        'price': 53500,
        'color': 'blue'
    },
    {
        'name': 'BMW M2',
        'manufacter': 'Q60174112',
        'price': 75650,
        'color': 'red'
    },
    {
        'name': 'SEAT LEON CUPRA',
        'manufacter': 'B60258512',
        'price': 45255,
        'color': 'yellow'
    },
    {
        'name': 'PORSCHE 911 GT3 RS',
        'manufacter': 'B60114712',
        'price': 224171,
        'color': 'black'
    },
    {
        'name': 'AUDI A3 S3',
        'manufacter': 'N0042609H',
        'price': 53900,
        'color': 'red'
    },
    {
        'name': 'VOLKSWAGEN POLO GTI',
        'manufacter': 'A60198512',
        'price': 29044,
        'color': 'blue'
    },
    {
        'name': 'BMW M3',
        'manufacter': 'Q60174112',
        'price': 111400,
        'color': 'yellow'
    },
    {
        'name': 'SEAT IBIZA FR',
        'manufacter': 'B60258512',
        'price': 20300,
        'color': 'black'
    },
];

module.exports = products;