const manufacters =  [
    {
      'name': 'SEAT',
      'cif': 'B60258512',
      'address': 'C. de Mayor, 7, 28055 Madrid'
    },
    {
      'name': 'VOLKSWAGEN',
      'cif': 'A60198512',
      'address': 'C. de Preciados, 5, 28026 Madrid'
    },
    {
      'name': 'AUDI',
      'cif': 'N0042609H',
      'address': 'C. de Canarias, 3, 28045 Madrid'
    },
    {
      'name': 'BMW',
      'cif': 'Q60174112',
      'address':' C. de Castillo de Papel, 1, 28044 Madrid'
    },
    {
      'name': 'PORSCHE',
      'cif': 'B60114712',
      'address': 'C. de Desengaño, 21, 28013 Madrid'
    }
];

module.exports = manufacters;